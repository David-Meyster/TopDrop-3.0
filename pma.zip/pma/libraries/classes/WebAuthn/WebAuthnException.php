<?php

declare(strict_types=1);

namespace PhpMyAdmin\WebAuthn;

use Exception;

class WebAuthnException extends Exception
{
}
