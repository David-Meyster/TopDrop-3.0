$.widget.bridge('uiTooltip', $.ui.tooltip);
